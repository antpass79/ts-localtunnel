import Koa from 'koa';

export class InjectableKoa extends Koa {
    constructor() {
        super();
    }
}