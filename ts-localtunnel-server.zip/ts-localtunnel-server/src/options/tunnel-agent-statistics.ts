export class TunnelAgentStatistics {
    connectedSockets: number = 0;
}