import Router from 'koa-router';

export class InjectableRouter extends Router {
    constructor() {
        super();
    }
}