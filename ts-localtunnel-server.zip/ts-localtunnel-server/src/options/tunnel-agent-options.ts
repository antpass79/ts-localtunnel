export interface ITunnelAgentOptions {
    clientId: string,
    maxSockets: number
}