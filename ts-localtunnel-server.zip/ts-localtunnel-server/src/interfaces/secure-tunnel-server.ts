export interface ISecureTunnelServer {
    listen(port: number, address: string): void;   
}