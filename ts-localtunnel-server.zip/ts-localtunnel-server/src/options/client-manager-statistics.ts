export class ClientManagerStatistics {
    tunnels: number = 0;
}