import { ITunnelAgent } from "../interfaces/tunnel-agent";

export class ClientOptions {
    id: any;
    tunnelAgent: ITunnelAgent | undefined;
}